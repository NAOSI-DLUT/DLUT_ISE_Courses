
public class LeasedSmartphone {
    
    private Smartphone phone;
    
    private String company;
    
    public LeasedSmartphone(Smartphone phone, String c) {
        this.phone = phone;
        company = c;
        int price = (int)(phone.getPrice() * 0.8);
        phone.setPrice(price);
    }
    
    public String getCompany() {
        return company;
    }
    
    public int getPrice() {
        return phone.getPrice();
    }
}
