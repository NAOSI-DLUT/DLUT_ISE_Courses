
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main11 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Swing Sample");
        Container contentPane = frame.getContentPane();
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        contentPane.add(panel);
        
        JButton button = new JButton("Please Push");
        contentPane.add(button);
        
        ButtonListener bl = new ButtonListener();
        button.addActionListener(bl);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(200, 100);
        frame.setVisible(true);
    }
}

class ButtonListener implements ActionListener {
    
    public void actionPerformed(ActionEvent e) {
        System.out.println("Pushed Button");
    }
}