
public class RentalSmartphone extends Smartphone {
    
    private int period;
    
    public RentalSmartphone(String name, int price, int period) {
        super(name, price);
        this.period = period;
    }
    
    public void setPeriod(int period) {
        this.period = period;
    }
    
    public int getPrice() {
        return price * period;
    }
}
