
class PC {
    int price;
    
    PC(int price) {
        this.price = price;
    }
    
    String getInfo() {
        return "$" + price;
    }
}

class DiscountedPC extends PC {
    
    DiscountedPC(int price) {
        super((int)(price * 0.8));
    }
    
    String getInfo() {
        return super.getInfo() + "!";
    }
}

public class Exec2 {
    
    public static void main(String[] args) {
        PC pc1 = new PC(250);
        System.out.println(pc1.getInfo());  // (1)
        
        DiscountedPC pc2 = new DiscountedPC(250);
        System.out.println(pc2.getInfo());  // (2)
        
        PC pc3 = new DiscountedPC(250);
        System.out.println(pc3.getInfo());  // (3)
        
        PC pc4 = pc1;
        System.out.println(pc4.getInfo());  // (4)
        
        DiscountedPC pc5 = (DiscountedPC)pc3;
        System.out.println(pc5.getInfo());  // (5)
    }
}
