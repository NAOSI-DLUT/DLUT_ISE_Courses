
public class Main3 {
    
    public static void main(String[] args) {
        Smartphone base = new Smartphone("ABC", 35000);
        LeasedSmartphone phone = new LeasedSmartphone(base, "Z");
        System.out.println("Company = " + phone.getCompany());
        System.out.println("Price = " + phone.getPrice());
    }
}
