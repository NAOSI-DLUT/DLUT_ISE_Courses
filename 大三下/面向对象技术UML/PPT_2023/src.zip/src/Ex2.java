
public class Ex2 {
    
    public static void main(String[] args) {
        int x = 123, y = 56;
        String s = "abc", t = "def";
        
        System.out.println(x + y);
        
        System.out.println(s + t);
        System.out.println(s + x);
        System.out.println(s + x + y);
        System.out.println(x + y + s);
    }
}
