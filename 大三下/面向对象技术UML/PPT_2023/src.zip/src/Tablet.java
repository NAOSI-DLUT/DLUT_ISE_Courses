
public class Tablet extends MobileDevice {
    
    public Tablet(String name) {
        super(name);
    }
    
    public String getName() {
        return name;
    }
    
    public void feature() {
        System.out.println(name +  " is Big");
    }
}
