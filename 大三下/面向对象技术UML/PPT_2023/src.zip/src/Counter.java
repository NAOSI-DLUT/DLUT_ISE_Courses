
public class Counter extends Subject {
    private int value;
    
    public Counter() {
        value = 0;
    }
    
    public void inc() {
        value++;
        notifyChange();
    }
    
    public void reset() {
        value = 0;
        notifyChange();
    }
    
    public Object getStatus() {
        return value;
    }
}
