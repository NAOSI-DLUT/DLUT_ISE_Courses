
public class Ex3 {
    
    public static void main(String[] args) {
        int result = sum(2);
        System.out.println(result);
        
        System.out.println(sum(5));
        
        System.out.println(sum(-1));
    }
    
    static int sum(int n) {
        if (n <= 0) {
            return 0;
        }
        int sum = 0;
        while (n > 0) {
            sum = sum + n;
            n--;
        }
        return sum;
    }
}
