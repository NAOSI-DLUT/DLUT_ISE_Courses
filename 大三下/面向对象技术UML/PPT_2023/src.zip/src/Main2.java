
public class Main2 {
    
    public static void main(String[] args) {
        RentalSmartphone phone = new RentalSmartphone("ABC", 2980, 12);
        System.out.println("Name = " + phone.getName());
        System.out.println("Price = " + phone.getPrice());
    }
}
