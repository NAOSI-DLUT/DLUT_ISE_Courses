
public class Ex1 {
    
    public static void main(String[] args) {
        int a = 123;
        String s = "DUT";
        
        System.out.println(a);
        
        System.out.println(s);
    }
}
