
public class MobilePhone extends MobileDevice {
    
    public MobilePhone(String name) {
        super(name);
    }
    
    public void feature() {
        System.out.println(name + " is Small");
    }
}
