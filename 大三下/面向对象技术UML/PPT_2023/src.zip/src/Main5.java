
public class Main5 {
    
    public static void main(String[] args) {
        MobileDevice device = new Tablet("Q");
        device.feature();
        
        //System.out.println(device.getName());
        
        Tablet tablet = (Tablet)device;
        System.out.println(tablet.getName());
    }
}
