
public class Main9 {
    
    public static void main(String[] args) {
        Thread thread = new Thread(new ThreadB());
        thread.start();
        
        for (int i = 0; i < 10; i++) {
            System.out.println("main thread: " + i);
        }
    }
}

class ThreadB implements Runnable {
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println("my thread: " + i);
        }
    }
}
