
public class NumericalObserver extends Observer {
    public void update(Subject s) {
        int value = (int)s.getStatus();
        System.out.println(value);
    }
}
