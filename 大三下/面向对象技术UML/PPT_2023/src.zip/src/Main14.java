
public class Main14 {
    public static void main(String[] args) {
        Counter counter = new Counter();
        NumericalObserver o1 = new NumericalObserver();
        GraphicObserver o2 = new GraphicObserver();
        
        counter.add(o1);
        counter.add(o2);
        
        counter.inc();
        counter.inc();
        counter.inc();
        
        counter.remove(o2);
        counter.reset();
        counter.inc();
        counter.inc();
    }
}
