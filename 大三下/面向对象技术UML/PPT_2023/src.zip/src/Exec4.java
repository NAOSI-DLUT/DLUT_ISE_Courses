
import java.util.*;

/*
class PC {
    int price;
    
    public PC(int price) {
        this.price = price;
    }
    
    public String getInfo() {
        return "$" + price;
    }
}
*/

/*
class DiscountedPC extends PC {
    
    DiscountedPC(int price) {
        super((int)(price * 0.8));
    }
    
    String getInfo() {
        return super.getInfo() + "!";
    }
}
*/

public class Exec4 {
    
    public static void main(String[] args) {
        PC pc1 = new PC(250);
        DiscountedPC pc2 = new DiscountedPC(250);
        
        List<PC> pcs = new ArrayList<>();
        pcs.add(pc1);
        pcs.add(pc2);
        pcs.add(new PC(100));
        for (PC pc : pcs) {
            System.out.println(pc.getInfo());  // (1)
        }
        
        pcs.remove(0);
        for (PC pc : pcs) {
            System.out.println(pc.getInfo());  // (2)
        }
    }
}
