
abstract public class MobileDevice {
    
    protected String name;
    
    protected MobileDevice(String name) {
        this.name = name;
    }
    
    abstract public void feature();
}
