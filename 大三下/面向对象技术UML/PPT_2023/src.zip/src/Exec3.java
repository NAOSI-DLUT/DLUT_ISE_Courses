
/*
class PC {
    int price;
    
    public PC(int price) {
        this.price = price;
    }
    
    public String getInfo() {
        return "$" + price;
    }
}
*/

class UsedPC {
    
    private PC pc;
    
    public UsedPC(PC pc) {
        this.pc = pc;
    }
    
    void cutPrice() {
        pc.price = pc.price / 2;
    }
    
    String getInfo() {
        return pc.getInfo();
    }
}

public class Exec3 {
    
    public static void main(String[] args) {
        PC pc1 = new PC(250);
        System.out.println(pc1.getInfo());  // (1)
        
        UsedPC pc2 = new UsedPC(pc1);
        System.out.println(pc2.getInfo());  // (2)
        
        pc2.cutPrice();
        System.out.println(pc2.getInfo());  // (3)
        
        pc1.price = 80;
        System.out.println(pc1.getInfo());  // (4)
        System.out.println(pc2.getInfo());  // (5)
    }
}
