
class Device {
    private int price;
    
    Device(int price) {
        this.price = price;
    }
    
    Device() {
        this(10);
    }
    
    void setPrice(int p) {
        price = p;
    }
    
    int getPrice() {
        return price;
    }
    
    String getInfo() {
        return "$" + price;
    }
}

public class Exec1 {
    
    public static void main(String[] args) {
        Device device1 = new Device(25);
        System.out.println(device1.getPrice());  // (1)
        
        Device device2 = new Device();
        System.out.println(device2.getInfo());   // (2)
        device2.setPrice(15);
        System.out.println(device2.getInfo());   // (3)
        
        Device device3 = device1;
        System.out.println(device3.getInfo());   // (4)
        device3.setPrice(40);
        System.out.println(device1.getInfo());   // (5)
        System.out.println(device3.getInfo());   // (6)
        
        device3 = device2;
        System.out.println(device3.getInfo());   // (7)
    }
}
