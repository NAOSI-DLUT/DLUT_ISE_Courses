
public class Smartphone {
    
    private String name;
    
    int price;
    
    public Smartphone(String name, int p) {
        this.name = name;
        price = p;
    }
    
    public Smartphone(String name) {
        this(name, 30000);
    }
    
    public String getName() {
        return name;
    }
    
    public void setPrice(int p) {
        price = p;
    }
    
    public int getPrice() {
        return price;
    }
    
    private String getPriceInfo() {
        return getPrice() + "-yen";
    }
    
    public void print() {
        System.out.println(name + ": " + getPriceInfo());
    }
}
