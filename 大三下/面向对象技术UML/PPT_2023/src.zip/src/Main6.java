
import java.util.*;

public class Main6 {
    public static void main(String[] args) {
        List<Smartphone> list = new ArrayList<>();
        list.add(new Smartphone("P", 35000));
        list.add(new Smartphone("Q"));
        list.add(new Smartphone("R", 28000));
        list.add(new Smartphone("S", 20000));
        
        for (Smartphone phone : list) {
            phone.print();
        }
    }
}
