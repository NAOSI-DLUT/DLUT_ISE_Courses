
public class GraphicObserver extends Observer {
    public void update(Subject s) {
        int value = (int)s.getStatus();
        for (int i = 0; i < value; i++) {
            System.out.print('*');
        }
        System.out.println();
    }
}
