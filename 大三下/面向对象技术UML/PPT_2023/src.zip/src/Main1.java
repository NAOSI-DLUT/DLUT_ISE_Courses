
public class Main1 {
    
    public static void main(String[] args) {
        Smartphone phone1 = new Smartphone("ABC", 35000);
        System.out.println("Price = " + phone1.price);
        System.out.println("Price = " + phone1.getPrice());
        
        Smartphone phone2 = new Smartphone("XYZ");
        System.out.println("Price = " + phone2.price);
        phone2.setPrice(phone2.price + 1000);
        System.out.println("Price = " + phone2.getPrice());
    }
}