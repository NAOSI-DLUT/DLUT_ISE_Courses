
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main13 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Swing Sample");
        Container contentPane = frame.getContentPane();
        
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        contentPane.add(panel);
        
        DrawingCanvas canvas = new DrawingCanvas();
        contentPane.add(canvas);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 300);
        frame.setVisible(true);
    }
}

class DrawingCanvas extends JPanel implements MouseListener {
    
    private int x = -1, y = -1;
    
    DrawingCanvas() {
        addMouseListener(this);
    }
    
    public void mouseClicked(MouseEvent e) {
        x = e.getX();
        y = e.getY();
        repaint();
    }
    
    public void mousePressed(MouseEvent e) {
    }
    
    public void mouseReleased(MouseEvent e) {
    }
    
    public void mouseEntered(MouseEvent e) {
    }
    
    public void mouseExited(MouseEvent e) {
    }
    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (x > 0 && y > 0) {
            g.setColor(Color.blue);
            g.drawOval(x - 15, y - 15, 30, 30);
        }
    }
}