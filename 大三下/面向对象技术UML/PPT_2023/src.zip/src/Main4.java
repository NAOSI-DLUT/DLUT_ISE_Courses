
public class Main4 {
    
    public static void main(String[] args) {
        MobilePhone phone = new MobilePhone("P");
        phone.feature();
        
        Tablet tablet = new Tablet("Q");
        tablet.feature();
        
        MobileDevice device;
        
        device = phone;
        device.feature();
        
        device = tablet;
        device.feature();
    }
}
